/**
 * @(#)ExtensionRegistryEventCaster.java
 *
* Copyright (c) 2010, Oracle and/or its affiliates. All rights reserved. 
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 * 
 * 
 * @author alamgir.farouk@oracle.com
 * 
 */
package javax.ide.event;

public interface ExtensionRegistrationListener
{
  public void registrationStarted(ExtensionRegistrationEvent e );
  public void registrationProgress(ExtensionRegistrationEvent e);
  public void registrationUpdate(ExtensionRegistrationEvent e);
  public void registrationCompleted(ExtensionRegistrationEvent e);
  public void registrationAborted(ExtensionRegistrationEvent e);
  public void registrationException(ExtensionRegistrationEvent e) ;
}
