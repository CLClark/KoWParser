package javax.ide.extension;

/**
 * The <tt>LoaderType</tt> enumeration specifies information about the loader
 * an extension wishes to use. This information is provided for each extension
 * in the {@link Extension2#getPreferredLoader()} method.
 */
@Deprecated
public enum LoaderType
{
  /**
   * When an extension is loaded in an isolated loader, it can only see classes
   * from extensions it depends on, their dependencies, or classpath entries
   * they provide.
   */
  ISOLATED {
    @Override
    public String toString() {
      return "isolated";
    }
  },
  
  /**
   * When an extension is loaded in a global loader, it can see classes from 
   * all other extensions loaded in the global loader.
   */
  GLOBAL {
    @Override
    public String toString() {
      return "global";
    }
  };
}
