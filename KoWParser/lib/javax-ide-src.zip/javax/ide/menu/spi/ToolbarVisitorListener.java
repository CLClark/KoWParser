package javax.ide.menu.spi;

import javax.ide.extension.OnDemandElementVisitorListener;

public interface ToolbarVisitorListener extends OnDemandElementVisitorListener
{
  void addedToToolbar(String toolbarId);
}
