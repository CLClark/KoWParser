/*
 * @(#)HasNameD.java
 */

package javax.ide.model.java.declaration;

/**
 * Common supertype for Declaration elements that have a name.
 *
 * @author Andy Yu
 */
public interface HasNameD
  extends Declaration
{
  /**
   * Gets the simple name of this element.
   *
   * @return The simple name of this element.
   */
  public String getName();
}
