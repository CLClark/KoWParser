/*
 * @(#)TypeVariableD.java
 */

package javax.ide.model.java.declaration;

import java.util.Collection;

/**
 * Represents a type variable.
 *
 * @author Andy Yu
 */
public interface TypeVariableD
  extends TypeD, HasNameD
{
  /**
   * Gets the bounds, in order.
   *
   * @return The collection of type declarations for the bounds of this
   * type variable, in order.
   */
  public Collection getBounds();

  /**
   * Gets the declaring generic declaration.
   *
   * @return The declaring generic declaration.
   */
  public GenericD getGenericDeclaration();

}
