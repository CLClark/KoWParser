/*
 * @(#)ElseClauseT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An else clause. JLS3 14.9. <p/>
 *
 * @author Andy Yu
 * */
public interface ElseClauseT
  extends CompoundStatementT
{
  // ----------------------------------------------------------------------

  /**
   * @return The owning if statement. Null if none (i.e. deformed tree).
   */
  public IfStatementT getOwningIf();
}
