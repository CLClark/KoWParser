/*
 * @(#)FieldVariableT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A field (or enum constant) variable. <p/>
 *
 * @author Andy Yu
 * */
public interface FieldVariableT
  extends MemberVariableT
{
  // ----------------------------------------------------------------------

  static final FieldVariableT[] EMPTY_ARRAY = new FieldVariableT[ 0 ];


  // ----------------------------------------------------------------------
}
