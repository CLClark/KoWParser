/*
 * @(#)LocalVariableDeclT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A local variable declaration. <p/>
 * 
 * @author Andy Yu
 * */
public interface LocalVariableDeclT
  extends VariableDeclT, BlockElementT
{
  // ----------------------------------------------------------------------
}
