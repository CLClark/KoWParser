/*
 * @(#)OperatorExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * Common supertype for multi-operand operations. Note: Here,
 * "operator" is NOT synonymous with "has operands". All expressions
 * may have operands, but not all expressions perform operations on
 * their operands. <p/>
 *
 * @author Andy Yu
 * */
public interface OperatorExpressionT
  extends ExpressionT
{
}
