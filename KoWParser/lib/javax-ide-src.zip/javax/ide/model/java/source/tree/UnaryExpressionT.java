/*
 * @(#)UnaryExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression performing a prefix or postfix operation, but not a
 * typecast operation. The prefix operations are: <p/>
 *
 * <pre>
 *   + - ++ -- ~ !
 * </pre>
 *
 * The postfix operations are: <p/>
 *
 * <pre>
 *   ++ -- 
 * </pre>
 *
 * @author Andy Yu
 * */
public interface UnaryExpressionT
  extends OperatorExpressionT
{
}
