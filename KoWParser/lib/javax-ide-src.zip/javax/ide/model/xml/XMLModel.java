/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.model.xml;
import javax.ide.model.Transaction;

/**
 *  The <CODE>XMLModel</CODE> class. Encapsulates the
 *  {@link org.w3c.dom.Document} interface to support
 *  reading from and writing into the model.
 */
public interface XMLModel extends Transaction
{
  /**
   * Gets the {@link org.w3c.dom.Document}.
   *
   * @return The dom document.
   */
  public org.w3c.dom.Document getDOMDocument();
}
